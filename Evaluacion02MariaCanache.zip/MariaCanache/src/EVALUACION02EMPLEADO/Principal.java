package EVALUACION02EMPLEADO;

import javax.swing.JOptionPane;

public class Principal {
     
	public static void main(String[] args) {
		
		Empleado E1=new Empleado();
		
		JOptionPane.showMessageDialog(null,"Bienvenidos al Sistema de Talento Humano" );
		
		E1.setNombre(JOptionPane.showInputDialog(null, "Ingrese el nombre"));
		E1.setApellidop(JOptionPane.showInputDialog(null, "Ingrese el Apellido Paterno"));
		E1.setApellidom(JOptionPane.showInputDialog(null, "Ingrese el Apellido Materno"));
		E1.setRut(JOptionPane.showInputDialog(null, "Ingrese el Rut"));
		E1.setCargo(JOptionPane.showInputDialog(null, "Ingrese el cargo"));
		E1.setDirecci�n(JOptionPane.showInputDialog(null, "Ingrese la direcci�n"));
		E1.setTel�fono(Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese el N�mero de Tel�fono")));
		E1.setEmail(JOptionPane.showInputDialog(null, "Ingrese la direcci�n de Email"));
		
		JOptionPane.showMessageDialog(null,"Nombre: "+E1.getNombre()+ "\n Apellido Paterno: " +E1.getApellidop()+ "\n Apellido Materno:" +E1.getApellidom()+ "\n Rut:" +E1.getRut()+ "\n Cargo:" +E1.getCargo()+ "\n Direcci�n:" +E1.getDirecci�n()+ "\n Telef�no:" +E1.getTel�fono()+ "\n Email:"  +E1.getEmail());
		
		
		
		
	}
}
