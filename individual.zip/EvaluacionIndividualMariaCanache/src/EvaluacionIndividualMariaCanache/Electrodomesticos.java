package EvaluacionIndividualMariaCanache;
//@Realizado por MariaCanache

public class Electrodomesticos { //Clase Padre
	
	 private String color_def;
	 private int peso_final;
	 protected int precio_final;
	 private char consumo_energetico_def;
	 protected final static int precio_base=100000;
	 protected final static String color="blanco";
	 protected final static String Consumo_Energetico="F";
	 protected final static int peso= 5;
	 
	
	 //Constructores
	 
	 
	 public Electrodomesticos(int precio_base,String color,String Consumo_Energetico,int peso ) {
		super();//Por defecto
	
	 }
	 
	
	 public Electrodomesticos() {
		super();
	}


	public Electrodomesticos(int peso, int precio_final) {
			super();//Peso y Precio
			this.peso_final = peso;
			this.precio_final = precio_final;
		}
	 
	 

	 public Electrodomesticos(String color_def, int peso, int precio_final, char consumo_energetico_def) {
			super();//Todos los atributos
			this.color_def = color_def;
			this.peso_final = peso;
			this.precio_final = precio_final;
			this.consumo_energetico_def = consumo_energetico_def;
		}


    //Get and Set
	public int getPrecio_final() {
		return precio_final;
	}



	public void setPrecio_final(int precio_final) {
		this.precio_final = precio_final;
	}



	public String getColor_def() {
		return color_def;
	}


	public String setColor_def(String color_def) {
		return this.color_def = color_def;
	}


	public static String getColor() {
		return color;
	}


	public char getConsumo_energetico_def() {
		return consumo_energetico_def;
	}


	public void setConsumo_energetico_def(char consumo_energetico_def) {
		this.consumo_energetico_def = consumo_energetico_def;
	}


	
   //Comprobar el consumo
	public void consumo_energetico_def() {
		
		consumo_energetico_def=charAt(Consumo_Energetico);
		
	}


	private char charAt(String consumoEnergetico) {
		
		return 0;
	}
	

	
	public void precio_final() {
		
		precio_final=precio_lav + precio_tv;
	}
	
	
	
	
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
}
	
	
	
	


