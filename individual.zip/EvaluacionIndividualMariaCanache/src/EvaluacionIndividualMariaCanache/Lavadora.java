package EvaluacionIndividualMariaCanache;

public class Lavadora  extends Electrodomesticos {
	 //Atributos
	private int carga;
	private int precio_lav;
	private int peso_lav;
    protected final static int carga_f=5;

     //Constructores
	public Lavadora(int precio_base, String color, String Consumo_Energetico, int peso) {
		super(precio_base, color, Consumo_Energetico, peso);
	}

	
	public Lavadora(int precio_base, String color, String Consumo_Energetico, int peso, int precio_lav, int peso_lav) {
		super(precio_base, color, Consumo_Energetico, peso);
		this.precio_lav = precio_lav;
		this.peso_lav = peso_lav;
	}

	public Lavadora(int precio_base, String color, String Consumo_Energetico, int peso, int carga) {
		super(precio_base, color, Consumo_Energetico, peso);
		this.carga = carga;
	}


	public int getCarga() {
		return carga;
	}


	public void setCarga(int carga) {
		this.carga = carga;
	}


	public int getPrecio_lav() {
		return precio_lav;
	}


	public void setPrecio_lav(int precio_lav) {
		this.precio_lav = precio_lav;
	}

	//Calculo del precio
	public void precio_lav() {
		
		precio_lav=precio_base+carga;
	}
	
	
	
	
	
	
	
	
	

}
