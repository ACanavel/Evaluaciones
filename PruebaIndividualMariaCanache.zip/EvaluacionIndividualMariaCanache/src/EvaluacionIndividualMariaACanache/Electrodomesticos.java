package EvaluacionIndividualMariaACanache;
//@Realizado por MariaCanache

public class Electrodomesticos { //Clase Padre
	
	 private String color_def;
	 private int peso_final;
	 protected String precio_final;
	 private String consumo_energetico_def;
	 private String tipo_electrodomestico;
	 protected final static int precio_base=100000;
	 protected final static String color="blanco";
	 protected final static String Consumo_Energetico="F";
	 protected final static int peso= 5;
	 
	
	 //Constructores
	 
	 
	 public Electrodomesticos(int precio_base,String color,String Consumo_Energetico,int peso ) {
		super();//Por defecto
	
	 }
	 
	 public Electrodomesticos() {
		super();
	}


	public Electrodomesticos(int peso, String precio_final) {
			super();//Peso y Precio
			this.peso_final = peso;
			this.precio_final = precio_final;
		}
	 
	 

	 public Electrodomesticos(String color_def, int peso, String precio_final, String consumo_energetico_def) {
			super();//Todos los atributos
			this.color_def = color_def;
			this.peso_final = peso;
			this.precio_final = precio_final;
			this.consumo_energetico_def = consumo_energetico_def;
		}


    //Get and Set
	public String getPrecio_final() {
		return precio_final;
	}



	public String setPrecio_final(String precio_final2) {
		return this.precio_final = precio_final2;
	}



	public String getColor_def() {
		return color_def;
	}


	public String setColor_def(String color_def) {
		return this.color_def = color_def;
	}


	public static String getColor() {
		return color;
	}


	public String getConsumo_energetico_def() {
		return consumo_energetico_def;
	}


	public String setConsumo_energetico_def(String consumo2) {
		return this.consumo_energetico_def = consumo2;
	
	}
	
	public String getTipo_electrodomestico() {
		return tipo_electrodomestico;
	}

	public String setTipo_electrodomestico(String tipo_electrodomestico) {
		return this.tipo_electrodomestico = tipo_electrodomestico;
	}

	//Comprobar el consumo
	public void consumo_energetico_def(char F) {
		
		if(consumo_energetico_def=="F") {
		
		consumo_energetico_def=charAt(Consumo_Energetico);
		}
		
	}

	private String charAt(String consumoEnergetico) {
		
		return null ;
	}

	public String setPrecio_tv(float precio_tv) {
		// TODO Auto-generated method stub
		return null;
	}

	public String setPrecio_lavadora(String precio2) {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getPrecio_lavadora() {
		// TODO Auto-generated method stub
		return null;
	}

	public float getPrecio_tv() {
		// TODO Auto-generated method stub
		return (Float) null;
	}

	public short setResoluci�n() {
		// TODO Auto-generated method stub
		return 0;
	}

	
	
	
	
	
	
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
}
	
	
	
	


