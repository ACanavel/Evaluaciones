package EvaluacionIndividualMariaACanache;

import javax.swing.JOptionPane;

public class Principal {
	
	public static void main(String[] args) {
	
		int i = 0,j=0,op,opp=0;
		  String color_e;
		  String Electrodomestico;
		  String tipo = null;
          short resoluci�n;
          int sintonizadortdt;
          float precio_tv = 0;
          char consumo_energetico_def;
          char consumo = 0;
          String consumo2;
          int carga=0;
          int precio_lav;
          int precio=0;
          String precio2;
          String precio_final=null;
		  final String color="blanco";
		  final int precio_base=100000;
		  

		  String Electrodomesticos[][]=new String[10][6];
		  
		  Electrodomesticos t=new Electrodomesticos();
		 
		  String color_e1=new String ("Negro");
		  String color_e2=new String ("Rojo");
		  String color_e3=new String ("Azul");
		  String color_e4=new String ("Gris");
		  
		  
		  do { //proceso
			  
			  JOptionPane.showMessageDialog(null,"Sistema Administrativo Comercial");
			  op=Integer.parseInt(JOptionPane.showInputDialog("Seleccione:"                          
	                  + "\n 1.Ingresar Electrodom�sticos  \n 2.Mostrar Electrodom�sticos   \n 3.Salir"));
			  
			  if(op==1) { //Ingresar electrodomesticos
				  
				  
					  for(i=0;i<10;i++) {
					  
						  if(t instanceof Electrodomesticos) {
							  
							  Electrodomestico=JOptionPane.showInputDialog("Ingrese el Tipo de Electrodom�stico"); //tipo de Electrodomestico
							  Electrodomestico=tipo;
							  Electrodomesticos[i][0]=t.setTipo_electrodomestico(tipo);
							  JOptionPane.showMessageDialog(null,t.getTipo_electrodomestico());
					  
							  color_e=JOptionPane.showInputDialog("Ingrese el color"); //color
							  
							  if(color_e.equalsIgnoreCase (color_e1)) {
	            			    	
		            			     color_e=color_e1;
		            			     Electrodomesticos[i][1]=t.setColor_def(color_e1);
							  
							  
							     if(color_e.equalsIgnoreCase (color_e2)) {
	            			    	
	                			    color_e=color_e2;
	                			    Electrodomesticos[i][1]=t.setColor_def(color_e2);
							  
							     }
	                			    if(color_e.equalsIgnoreCase (color_e3)) {
	                			    	
	                    			    color_e=color_e3;
	                    			    Electrodomesticos[i][1]=t.setColor_def(color_e3);
	                			    }
					  
	                    			    if(color_e.equalsIgnoreCase (color_e4)) {
	                    			    	
	                        			    color_e=color_e4;
	                        			    Electrodomesticos[i][1]=t.setColor_def(color_e4);
	                        			    
	                        			    
	                    			    } else {
	                    			    	
	                    			    	color_e= color;
	                    			    	Electrodomesticos[i][1]=t.setColor_def(color);
	                    			   
	                    			    }
	                    			    JOptionPane.showMessageDialog(null,t.getColor_def());//Color
	                    			    }
							         
							          
							          //precio Televisor
							          resoluci�n=(short) Integer.parseInt(JOptionPane.showInputDialog("Ingrese las pulgadas"));
							          resoluci�n=t.setResoluci�n();
							          sintonizadortdt=Integer.parseInt(JOptionPane.showInputDialog("�Tiene SintonizadorTDT?" 
							        		      + "\n 1.Si  \n 2.No"));
							         
							      		if(resoluci�n>40) {
							      		   
											if(sintonizadortdt==1) {
							      			
							      			precio_tv=(float) (precio_base + (precio_base)*(0.30) + 45000);
							      			Electrodomesticos[i][2]=(String) t.setPrecio_tv(precio_tv);
							      			
							      		}	else {
							      			
							      		   precio_tv=(float)precio_base;
							      		   Electrodomesticos[i][2]=(String) t.setPrecio_tv(precio_tv);
							      		}
											JOptionPane.showMessageDialog(null, t.getPrecio_tv());//precio televisor
							      		}
							      		
							      		
							      		//consumo Energetico
							      		consumo_energetico_def=JOptionPane.showInputDialog("Ingrese el Consumo Energ�tico").charAt(0);
							      		consumo_energetico_def=consumo;
							      		consumo2=String.valueOf(consumo);
							      		Electrodomesticos[i][3]=t.setConsumo_energetico_def(consumo2);
							      		
							      		//Precio Lavadora
							      		carga=Integer.parseInt(JOptionPane.showInputDialog("�Cu�ntos kilos de Carga?"));
							      		
							      		if(carga>30) {
							      			
							      			precio_lav=precio_base + 40000;
							      			precio_lav=precio;
							      			precio2=String.valueOf(precio);
							      			Electrodomesticos[i][4]=t.setPrecio_lavadora(precio2);
							      			
							      		}else {
							      			
							      			
							      			precio_lav=precio_base+8500;
							      			precio_lav=precio;
							      			precio2=String.valueOf(precio);
							      			Electrodomesticos[i][4]=t.setPrecio_lavadora(precio2);
							      			
							      		}
							      		
							      		JOptionPane.showMessageDialog(null, t.getPrecio_lavadora());
							      		
							      		 precio_final = precio_tv + precio2;
							      		 precio_final=t.setPrecio_final(precio_final);
							      		 Electrodomesticos[i][5]=t.getPrecio_final();
							      		JOptionPane.showMessageDialog(null,"Total:" +t.getPrecio_final());
							      	} 
						
						  }
				  
					  }
				  
				   if(op==2) {
					   
					   JOptionPane.showInputDialog(null, Electrodomesticos[i][j]); 
					   
				   }
			  
			  
		  }while(op==3);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}
}
