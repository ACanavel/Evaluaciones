package AUTOMOVIL;
//Realizado por @MariaCanache
import java.io.ObjectInputStream.GetField;
//Autor:Maria Canache

import javax.swing.JOptionPane;

public class Principal {

	public static void main(String[] args) {
		
		Automovil A1=new Automovil();
		
		A1.setMarca(JOptionPane.showInputDialog(null, "Ingrese la Marca del Auto"));
		A1.setModelo(JOptionPane.showInputDialog(null, "Ingrese el Modelo del Auto"));
		A1.setA�o(Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el A�o del Auto")));
		A1.setPrecio(Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el Precio neto")));
		A1.preciofinal();
		
		JOptionPane.showMessageDialog(null,"El Auto marca "+A1.getMarca()+ "\n Modelo" +A1.getModelo()+ "\n A�o" +A1.getA�o()+ "\n tiene un precio final de "+A1.getPrecio());
		
	}

}
