package EVALUACION02EMPLEADOPRIVADO_PUBLICO;

public class Empleado {

	String rut;
	String nombres;
	String apellido;
	String direcci�n;
	int tel�fono;
	double sueldo;
	
	
	public Empleado() {
		super();
	}


	public Empleado(String rut, String nombres, String apellido, String direcci�n, int telef�no, double sueldo) {
		super();
		this.rut = rut;
		this.nombres = nombres;
		this.apellido = apellido;
		this.direcci�n = direcci�n;
		this.tel�fono = telef�no;
		this.sueldo = sueldo;
	}


	public String getRut() {
		return rut;
	}


	public void setRut(String rut) {
		this.rut = rut;
	}


	public String getNombres() {
		return nombres;
	}


	public void setNombres(String nombres) {
		this.nombres = nombres;
	}


	public String getApellido() {
		return apellido;
	}


	public void setApellido(String apellido) {
		this.apellido = apellido;
	}


	public String getDirecci�n() {
		return direcci�n;
	}


	public void setDirecci�n(String direcci�n) {
		this.direcci�n = direcci�n;
	}


	public int getTelef�no() {
		return tel�fono;
	}


	public void setTelef�no(int telef�no) {
		this.tel�fono = telef�no;
	}


	public double getSueldo() {
		return sueldo;
	}


	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}
	
	
}
