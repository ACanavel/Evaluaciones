package EvaluacionIndividualMariaACanache;

public class Televisor  extends Electrodomesticos {
	
	  private short resoluci�n;
	  private boolean sintonizadortdt;
	  private float precio_tv;
	  private int peso_tv;
	  private int precio_resoluci�n;
	  private int precio_sintonizadortdt;
	  protected final static short resoluci�n_tv=20;
	  protected final static boolean sintonizador_tv=false;
	
	  
	  public Televisor(int precio_base, String color, String Consumo_Energetico, int peso) {
		super(precio_base, color, Consumo_Energetico, peso);
	}
	  
	 public Televisor() {
		super();
	}

	public Televisor(int precio_base, String color, String Consumo_Energetico, int peso, int precio_tv) {
		super(precio_base, color, Consumo_Energetico, peso);
		this.precio_tv = precio_tv;
		this.peso_tv=peso_tv;
	}




	public Televisor(int precio_base, String color, String Consumo_Energetico, int peso, short resoluci�n,
			boolean sintonizadortdt) {
		super(precio_base, color, Consumo_Energetico, peso);
		this.resoluci�n = resoluci�n;
		this.sintonizadortdt = sintonizadortdt;
	}


	public float getPrecio_tv() {
		return precio_tv;
	}

	public String setPrecio_tv(float precio_tv) {
		return null;
	}

	public short getResoluci�n() {
		return resoluci�n;
	}


	public void setResoluci�n(short resoluci�n) {
		this.resoluci�n = resoluci�n;
	}


	public boolean isSintonizadortdt() {
		return sintonizadortdt;
	}


	public void setSintonizadortdt(boolean sintonizadortdt) {
		this.sintonizadortdt = sintonizadortdt;
	}

	
	  
	

}
