package EvaluacionIndividualMariaCanache;

public class Televisor  extends Electrodomesticos {
	
	  private short resoluci�n;
	  private boolean sintonizadortdt;
	  private int precio_tv;
	  private int peso_tv;
	  private int precio_resoluci�n;
	  private int precio_sintonizadortdt;
	  protected final static short resoluci�n_tv=20;
	  protected final static boolean sintonizador_tv=false;
	
	  
	  public Televisor(int precio_base, String color, String Consumo_Energetico, int peso) {
		super(precio_base, color, Consumo_Energetico, peso);
	}


	 public Televisor(int precio_base, String color, String Consumo_Energetico, int peso, int precio_tv) {
		super(precio_base, color, Consumo_Energetico, peso);
		this.precio_tv = precio_tv;
		this.peso_tv=peso_tv;
	}




	public Televisor(int precio_base, String color, String Consumo_Energetico, int peso, short resoluci�n,
			boolean sintonizadortdt) {
		super(precio_base, color, Consumo_Energetico, peso);
		this.resoluci�n = resoluci�n;
		this.sintonizadortdt = sintonizadortdt;
	}


	public int getPrecio_resoluci�n() {
		return precio_resoluci�n;
	}


	public void setPrecio_resoluci�n(int precio_resoluci�n) {
		this.precio_resoluci�n = precio_resoluci�n;
	}


	public int getPrecio_sintonizadortdt() {
		return precio_sintonizadortdt;
	}


	public void setPrecio_sintonizadortdt(int precio_sintonizadortdt) {
		this.precio_sintonizadortdt = precio_sintonizadortdt;
	}


	public short getResoluci�n() {
		return resoluci�n;
	}


	public void setResoluci�n(short resoluci�n) {
		this.resoluci�n = resoluci�n;
	}


	public boolean isSintonizadortdt() {
		return sintonizadortdt;
	}


	public void setSintonizadortdt(boolean sintonizadortdt) {
		this.sintonizadortdt = sintonizadortdt;
	}

	public void precio_tv() {
		
		precio_tv=precio_base + precio_resoluci�n+precio_sintonizadortdt;
			
	} 
	  
	

}
