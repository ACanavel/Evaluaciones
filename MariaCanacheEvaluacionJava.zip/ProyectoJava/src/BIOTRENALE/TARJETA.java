package BIOTRENALE;
/* Autor
 * @MariaCanache
 */
public class TARJETA extends USUARIO {

	public TARJETA() {
		super();
	}

	public TARJETA(int numero_tarjeta, String tipo_tarjeta, float saldo, String tipo_usuario, int tiempo_activo,
			float descuento) {
		super();
		this.numero_tarjeta = numero_tarjeta;
		this.tipo_tarjeta = tipo_tarjeta;
		this.saldo = saldo;
		this.tipo_usuario = tipo_usuario;
		this.tiempo_activo = tiempo_activo;
		this.descuento = descuento;
	}

	public void numero_tarjeta() {
       
		numero_tarjeta= (int)(Math.random()*100000000+1);
	}
	
     public void saldo (int saldo,int abono) {
	       saldo=500;
	       saldo=saldo+abono;
	  
     }
        
    


}

	



