package BIOTRENALE;
/* Autor
 * @MariaCanache
 */
public class USUARIO {

	String nombre;
	String apellido;
	String Run;
	int Edad;
	int numero_tarjeta;
	String tipo_tarjeta;
	float saldo;
	String tipo_usuario;
	int tiempo_activo;
	float descuento;
	
	  public USUARIO() {
		super();
	}
	
	public USUARIO(String nombre, String apellido, String run, int edad) {
	super();
	this.nombre = nombre;
	this.apellido = apellido;
	Run = run;
	this.Edad = edad;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getRun() {
		return Run;
	}

	public void setRun(String run) {
		Run = run;
	}

	public int getEdad() {
		return Edad;
	}

	public void setEdad(int edad) {
		this.Edad = Edad;
	}

	public int getNumero_tarjeta() {
		return numero_tarjeta;
	}

	public void setNumero_tarjeta(int numero_tarjeta) {
		this.numero_tarjeta = numero_tarjeta;
	}

	public String getTipo_tarjeta() {
		return tipo_tarjeta;
	}

	public void setTipo_tarjeta(String tipo_tarjeta) {
		this.tipo_tarjeta = tipo_tarjeta;
	}

	public float getSaldo() {
		return saldo;
	}

	public void setSaldo(float saldo) {
		this.saldo = saldo;
	}

	public String getTipo_usuario() {
		return tipo_usuario;
	}

	public void setTipo_usuario(String tipo_usuario) {
		this.tipo_usuario = tipo_usuario;
	}

	public int getTiempo_activo() {
		return tiempo_activo;
	}

	public void setTiempo_activo(int tiempo_activo) {
		this.tiempo_activo = tiempo_activo;
	}

	public float getDescuento() {
		return descuento;
	}

	public void setDescuento(float descuento) {
		this.descuento = descuento;
	}

		
	}

    

	
	
	
    
     

	
	
	

