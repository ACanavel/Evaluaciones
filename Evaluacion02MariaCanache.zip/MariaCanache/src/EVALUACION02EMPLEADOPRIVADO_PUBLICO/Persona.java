package EVALUACION02EMPLEADOPRIVADO_PUBLICO;

import javax.swing.JOptionPane;

public class Persona {
	
	public static void main(String[] args) {
		int op=0;
		
		do {
			
		
		Privado eprivado=new Privado();
		Publico epublico=new Publico();
		
		JOptionPane.showMessageDialog(null,"Bienvenidos al Sistema de Registro Nacional de Empleados" );
		op=Integer.parseInt(JOptionPane.showInputDialog("Seleccione: Tipo de Empleado"
    			+ "\n 1.Privado  \n 2.Publico  \n 3.Salir "));
		
		if(op==1){
		
		eprivado.setRut("12345678-8");
		eprivado.setNombres("Francisco");
		eprivado.setApellido("Risopatr�n De Lourdes");
		eprivado.setDirecci�n("Juan Bosco 1786");
		eprivado.setTel�fono("976834616");
		eprivado.setSueldo("6000000");
		eprivado.setComuna("Comuna Las Condes");
		eprivado.setEmpresa("Gerencia");
		
		JOptionPane.showMessageDialog(null,"Rut:" +eprivado.getRut()+ "\n Nombre:" +eprivado.getNombres()+ "\n Apellido:" +eprivado.getApellido()+ "\n Direcci�n:" +eprivado.getDirecci�n()+ " \n Tel�fono:" +eprivado.getTelef�no()+ "\n Sueldo:" +eprivado.getSueldo()+"\n Comuna:" +eprivado.getComuna()+ "\n Empresa:" +eprivado.getEmpresa());
		
		}
		
		if(op==2) {
		
		epublico.setRut("152423566");
		epublico.setNombres("Fernando");
		epublico.setApellido("Mellado Salinas");
		epublico.setDirecci�n("Los Laureles 45");
		epublico.setTel�fono("945281947");
		epublico.setSueldo("780000");
		epublico.setDepartamento("Administrativo");
		epublico.setMunicipalidad("Municipalidad de Los Alamos");
		
		JOptionPane.showMessageDialog(null,"Rut:" +epublico.getRut()+ "\n Nombre:" +epublico.getNombres()+ "\n Apellido:" +epublico.getApellido()+ "\n Direcci�n:" +epublico.getDirecci�n()+ " \n Tel�fono:" +epublico.getTelef�no()+ "\n Sueldo:" +epublico.getSueldo()+"\n Departamento:" +epublico.getDepartamento()+ "\n Municipalidad:" +epublico.getMunicipalidad());
		
		}
		
		}while(op==3);
			
		
		
	}
}
