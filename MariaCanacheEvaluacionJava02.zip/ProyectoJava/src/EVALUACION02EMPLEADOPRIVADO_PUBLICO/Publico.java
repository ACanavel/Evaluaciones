package EVALUACION02EMPLEADOPRIVADO_PUBLICO;

public class Publico extends Empleado{
	
	
	private String municipalidad;
	private String departamento;
	
	
	public String getRut() {
		return rut;
	}
	public void setRut(String rut) {
		this.rut = rut;
	}
	public String getNombres() {
		return nombres;
	}
	public void setNombres(String nombres) {
		this.nombres = nombres;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public String getDirecci�n() {
		return direcci�n;
	}
	public void setDirecci�n(String direcci�n) {
		this.direcci�n = direcci�n;
	}
	public int getTelef�no() {
		return tel�fono;
	}
	public void setTelef�no(int telef�no) {
		this.tel�fono = telef�no;
	}
	public double getSueldo() {
		return sueldo;
	}
	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}
	public String getMunicipalidad() {
		return municipalidad;
	}
	public void setMunicipalidad(String municipalidad) {
		this.municipalidad = municipalidad;
	}
	public String getDepartamento() {
		return departamento;
	}
	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}
	
	
		
	}
	
	
	
	
	
    
	
	
	
	
	
	


