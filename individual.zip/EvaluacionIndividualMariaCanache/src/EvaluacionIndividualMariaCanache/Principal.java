package EvaluacionIndividualMariaCanache;

import javax.swing.JOptionPane;

public class Principal {
	
	public static void main(String[] args) {
	 int i,j,op=0;
	 String color;
	 
	String Electrodomesticos[][]=new String[5][10];
	Electrodomesticos E=new Electrodomesticos();
	    Object TvSmart = new Electrodomesticos();
	    Object Lavadorafrontal= new Electrodomesticos();
	    
	do {
		
		JOptionPane.showMessageDialog(null,"Sistema Administrativo Comercial");
		op=Integer.parseInt(JOptionPane.showInputDialog("Seleccione:"                         
		                            + "\n 1.Ingresar Electrodom�sticos  \n 2.Mostrar Electrodom�sticos   \n 3.Salir"));
		
		      if(op==1) {
			
			       for(i=0;i<5;i++) {
			    	    
			    	   if(TvSmart instanceof Electrodomesticos) {
			    	    
			    		   color=JOptionPane.showInputDialog("Ingrese el Color");
			    	       Electrodomesticos[i][0]=E.setColor_def(null);
			    	       
			    	   
			    	   
			    	   
			    	   
			    	   
			    	   
			    	   
			       }
				
				
				
				
				
				
				
				
				
		
			
			
			
			
			
			
			
			
			
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}while(op==3);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}

	private static Object i(int i, int j) {
		// TODO Auto-generated method stub
		return null;
	}	

}
