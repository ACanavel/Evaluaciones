/*==============================================================*/
/* DBMS name:      Sybase SQL Anywhere 12                       */
/* Created on:     06/03/2020 17:11:34                          */
/*==============================================================*/


if exists(select 1 from sys.sysforeignkey where role='FK_ESTABLEC_ESTABLECE_PROMOCIO') then
    alter table ESTABLECEN
       delete foreign key FK_ESTABLEC_ESTABLECE_PROMOCIO
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_ESTABLEC_ESTABLECE_FUNCIONE') then
    alter table ESTABLECEN
       delete foreign key FK_ESTABLEC_ESTABLECE_FUNCIONE
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_GENERAN_GENERAN_COMENTAR') then
    alter table GENERAN
       delete foreign key FK_GENERAN_GENERAN_COMENTAR
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_GENERAN_GENERAN2_FUNCIONE') then
    alter table GENERAN
       delete foreign key FK_GENERAN_GENERAN2_FUNCIONE
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_INTEGRAD_INTEGRADO_ACTORES') then
    alter table INTEGRADO
       delete foreign key FK_INTEGRAD_INTEGRADO_ACTORES
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_INTEGRAD_INTEGRADO_ELENCO') then
    alter table INTEGRADO
       delete foreign key FK_INTEGRAD_INTEGRADO_ELENCO
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_SALA_TIENE_CINE') then
    alter table SALA
       delete foreign key FK_SALA_TIENE_CINE
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_SE_CONFO_SE_CONFOR_ELENCO') then
    alter table SE_CONFORMA
       delete foreign key FK_SE_CONFO_SE_CONFOR_ELENCO
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_SE_CONFO_SE_CONFOR_PELICULA') then
    alter table SE_CONFORMA
       delete foreign key FK_SE_CONFO_SE_CONFOR_PELICULA
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_SE_PROYE_SE_PROYEC_CINE') then
    alter table SE_PROYECTA
       delete foreign key FK_SE_PROYE_SE_PROYEC_CINE
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_SE_PROYE_SE_PROYEC_PELICULA') then
    alter table SE_PROYECTA
       delete foreign key FK_SE_PROYE_SE_PROYEC_PELICULA
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_SE_VEN_SE_VEN_FUNCIONE') then
    alter table SE_VEN
       delete foreign key FK_SE_VEN_SE_VEN_FUNCIONE
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_SE_VEN_SE_VEN2_SALA') then
    alter table SE_VEN
       delete foreign key FK_SE_VEN_SE_VEN2_SALA
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_TRABAJA_TRABAJA_DIRECTOR') then
    alter table TRABAJA
       delete foreign key FK_TRABAJA_TRABAJA_DIRECTOR
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_TRABAJA_TRABAJA2_ELENCO') then
    alter table TRABAJA
       delete foreign key FK_TRABAJA_TRABAJA2_ELENCO
end if;

drop index if exists ACTORES.ACTORES_PK;

drop table if exists ACTORES;

drop index if exists CINE.CINE_PK;

drop table if exists CINE;

drop index if exists COMENTARIOS.COMENTARIOS_PK;

drop table if exists COMENTARIOS;

drop index if exists DIRECTOR.DIRECTOR_PK;

drop table if exists DIRECTOR;

drop index if exists ELENCO.ELENCO_PK;

drop table if exists ELENCO;

drop index if exists ESTABLECEN.ESTABLECEN_FK;

drop index if exists ESTABLECEN.ESTABLECEN2_FK;

drop index if exists ESTABLECEN.ESTABLECEN_PK;

drop table if exists ESTABLECEN;

drop index if exists FUNCIONES.FUNCIONES_PK;

drop table if exists FUNCIONES;

drop index if exists GENERAN.GENERAN_FK;

drop index if exists GENERAN.GENERAN2_FK;

drop index if exists GENERAN.GENERAN_PK;

drop table if exists GENERAN;

drop index if exists INTEGRADO.INTEGRADO_FK;

drop index if exists INTEGRADO.INTEGRADO2_FK;

drop index if exists INTEGRADO.INTEGRADO_PK;

drop table if exists INTEGRADO;

drop index if exists PELICULA.PELICULA_PK;

drop table if exists PELICULA;

drop index if exists PROMOCIONES.PROMOCIONES_PK;

drop table if exists PROMOCIONES;

drop index if exists SALA.TIENE_FK;

drop index if exists SALA.SALA_PK;

drop table if exists SALA;

drop index if exists SE_CONFORMA.SE_CONFORMA_FK;

drop index if exists SE_CONFORMA.SE_CONFORMA2_FK;

drop index if exists SE_CONFORMA.SE_CONFORMA_PK;

drop table if exists SE_CONFORMA;

drop index if exists SE_PROYECTA.SE_PROYECTA_FK;

drop index if exists SE_PROYECTA.SE_PROYECTA2_FK;

drop index if exists SE_PROYECTA.SE_PROYECTA_PK;

drop table if exists SE_PROYECTA;

drop index if exists SE_VEN.SE_VEN_FK;

drop index if exists SE_VEN.SE_VEN2_FK;

drop index if exists SE_VEN.SE_VEN_PK;

drop table if exists SE_VEN;

drop index if exists TRABAJA.TRABAJA_FK;

drop index if exists TRABAJA.TRABAJA2_FK;

drop index if exists TRABAJA.TRABAJA_PK;

drop table if exists TRABAJA;

/*==============================================================*/
/* Table: ACTORES                                               */
/*==============================================================*/
create table ACTORES 
(
   ID_ACTOR             integer                        not null,
   NOM_ACTOR            varchar(25)                    not null,
   NACIONALIDAD         varchar(12)                    not null,
   PARTICIPACION        varchar(30)                    not null,
   constraint PK_ACTORES primary key (ID_ACTOR)
);

/*==============================================================*/
/* Index: ACTORES_PK                                            */
/*==============================================================*/
create unique index ACTORES_PK on ACTORES (
ID_ACTOR ASC
);

/*==============================================================*/
/* Table: CINE                                                  */
/*==============================================================*/
create table CINE 
(
   ID_CINE              integer                        not null,
   SALA                 integer                        not null,
   NOMBRE_CINE          varchar(15)                    not null,
   DIRECCION            varchar(50)                    not null,
   TELEFONO             integer                        not null,
   constraint PK_CINE primary key (ID_CINE)
);

/*==============================================================*/
/* Index: CINE_PK                                               */
/*==============================================================*/
create unique index CINE_PK on CINE (
ID_CINE ASC
);

/*==============================================================*/
/* Table: COMENTARIOS                                           */
/*==============================================================*/
create table COMENTARIOS 
(
   ID_OPINION           integer                        not null,
   NOMBRE               varchar(25)                    not null,
   EDAD                 integer                        null,
   FECHA_OP             date                           not null,
   FILME                varchar(30)                    not null,
   constraint PK_COMENTARIOS primary key (ID_OPINION)
);

/*==============================================================*/
/* Index: COMENTARIOS_PK                                        */
/*==============================================================*/
create unique index COMENTARIOS_PK on COMENTARIOS (
ID_OPINION ASC
);

/*==============================================================*/
/* Table: DIRECTOR                                              */
/*==============================================================*/
create table DIRECTOR 
(
   ID_DIRECTOR          integer                        not null,
   NOM_DIR              varchar(25)                    not null,
   NACIONALIDAD         varchar(12)                    not null,
   TRABAJOS             varchar(30)                    not null,
   constraint PK_DIRECTOR primary key (ID_DIRECTOR)
);

/*==============================================================*/
/* Index: DIRECTOR_PK                                           */
/*==============================================================*/
create unique index DIRECTOR_PK on DIRECTOR (
ID_DIRECTOR ASC
);

/*==============================================================*/
/* Table: ELENCO                                                */
/*==============================================================*/
create table ELENCO 
(
   ID_ELENCO            integer                        not null,
   PELICULA             varchar(30)                    not null,
   constraint PK_ELENCO primary key (ID_ELENCO)
);

/*==============================================================*/
/* Index: ELENCO_PK                                             */
/*==============================================================*/
create unique index ELENCO_PK on ELENCO (
ID_ELENCO ASC
);

/*==============================================================*/
/* Table: ESTABLECEN                                            */
/*==============================================================*/
create table ESTABLECEN 
(
   ID_PROMOCION         integer                        not null,
   ID_FUNCION           integer                        not null,
   constraint PK_ESTABLECEN primary key (ID_PROMOCION, ID_FUNCION)
);

/*==============================================================*/
/* Index: ESTABLECEN_PK                                         */
/*==============================================================*/
create unique index ESTABLECEN_PK on ESTABLECEN (
ID_PROMOCION ASC,
ID_FUNCION ASC
);

/*==============================================================*/
/* Index: ESTABLECEN2_FK                                        */
/*==============================================================*/
create index ESTABLECEN2_FK on ESTABLECEN (
ID_FUNCION ASC
);

/*==============================================================*/
/* Index: ESTABLECEN_FK                                         */
/*==============================================================*/
create index ESTABLECEN_FK on ESTABLECEN (
ID_PROMOCION ASC
);

/*==============================================================*/
/* Table: FUNCIONES                                             */
/*==============================================================*/
create table FUNCIONES 
(
   ID_FUNCION           integer                        not null,
   FECHA_FUN            date                           not null,
   HORA                 time                           not null,
   PELICULA             varchar(30)                    not null,
   constraint PK_FUNCIONES primary key (ID_FUNCION)
);

/*==============================================================*/
/* Index: FUNCIONES_PK                                          */
/*==============================================================*/
create unique index FUNCIONES_PK on FUNCIONES (
ID_FUNCION ASC
);

/*==============================================================*/
/* Table: GENERAN                                               */
/*==============================================================*/
create table GENERAN 
(
   ID_OPINION           integer                        not null,
   ID_FUNCION           integer                        not null,
   constraint PK_GENERAN primary key (ID_OPINION, ID_FUNCION)
);

/*==============================================================*/
/* Index: GENERAN_PK                                            */
/*==============================================================*/
create unique index GENERAN_PK on GENERAN (
ID_OPINION ASC,
ID_FUNCION ASC
);

/*==============================================================*/
/* Index: GENERAN2_FK                                           */
/*==============================================================*/
create index GENERAN2_FK on GENERAN (
ID_FUNCION ASC
);

/*==============================================================*/
/* Index: GENERAN_FK                                            */
/*==============================================================*/
create index GENERAN_FK on GENERAN (
ID_OPINION ASC
);

/*==============================================================*/
/* Table: INTEGRADO                                             */
/*==============================================================*/
create table INTEGRADO 
(
   ID_ACTOR             integer                        not null,
   ID_ELENCO            integer                        not null,
   constraint PK_INTEGRADO primary key (ID_ACTOR, ID_ELENCO)
);

/*==============================================================*/
/* Index: INTEGRADO_PK                                          */
/*==============================================================*/
create unique index INTEGRADO_PK on INTEGRADO (
ID_ACTOR ASC,
ID_ELENCO ASC
);

/*==============================================================*/
/* Index: INTEGRADO2_FK                                         */
/*==============================================================*/
create index INTEGRADO2_FK on INTEGRADO (
ID_ELENCO ASC
);

/*==============================================================*/
/* Index: INTEGRADO_FK                                          */
/*==============================================================*/
create index INTEGRADO_FK on INTEGRADO (
ID_ACTOR ASC
);

/*==============================================================*/
/* Table: PELICULA                                              */
/*==============================================================*/
create table PELICULA 
(
   ID_PELICULA          integer                        not null,
   TITULO_DISTRIB       varchar(30)                    not null,
   TITULO_ORIGINAL      varchar(30)                    not null,
   GENERO               varchar(10)                    not null,
   IDIOMA               varchar(10)                    not null,
   SUBTIT_E             smallint                       not null,
   FECHA_PRODUC         date                           not null,
   SITIO_WEB            varchar(20)                    not null,
   DURACION             time                           not null,
   FECHA_ESTRENO        date                           not null,
   RESUMEN              varchar(50)                    not null,
   ELENCO               varchar(50)                    not null,
   CALIFICACION         integer                        not null,
   constraint PK_PELICULA primary key (ID_PELICULA)
);

/*==============================================================*/
/* Index: PELICULA_PK                                           */
/*==============================================================*/
create unique index PELICULA_PK on PELICULA (
ID_PELICULA ASC
);

/*==============================================================*/
/* Table: PROMOCIONES                                           */
/*==============================================================*/
create table PROMOCIONES 
(
   ID_PROMOCION         integer                        not null,
   TIPO_PROMOCION       varchar(15)                    not null,
   DESCUENTO            real                           not null,
   FUNCION              integer                        null,
   constraint PK_PROMOCIONES primary key (ID_PROMOCION)
);

/*==============================================================*/
/* Index: PROMOCIONES_PK                                        */
/*==============================================================*/
create unique index PROMOCIONES_PK on PROMOCIONES (
ID_PROMOCION ASC
);

/*==============================================================*/
/* Table: SALA                                                  */
/*==============================================================*/
create table SALA 
(
   ID_SALA              integer                        not null,
   ID_CINE              integer                        not null,
   NOMBRE_SALA          varchar(10)                    not null,
   NUM_BUTACAS          integer                        not null,
   FUNCION              integer                        not null,
   constraint PK_SALA primary key (ID_SALA)
);

/*==============================================================*/
/* Index: SALA_PK                                               */
/*==============================================================*/
create unique index SALA_PK on SALA (
ID_SALA ASC
);

/*==============================================================*/
/* Index: TIENE_FK                                              */
/*==============================================================*/
create index TIENE_FK on SALA (
ID_CINE ASC
);

/*==============================================================*/
/* Table: SE_CONFORMA                                           */
/*==============================================================*/
create table SE_CONFORMA 
(
   ID_ELENCO            integer                        not null,
   ID_PELICULA          integer                        not null,
   constraint PK_SE_CONFORMA primary key (ID_ELENCO, ID_PELICULA)
);

/*==============================================================*/
/* Index: SE_CONFORMA_PK                                        */
/*==============================================================*/
create unique index SE_CONFORMA_PK on SE_CONFORMA (
ID_ELENCO ASC,
ID_PELICULA ASC
);

/*==============================================================*/
/* Index: SE_CONFORMA2_FK                                       */
/*==============================================================*/
create index SE_CONFORMA2_FK on SE_CONFORMA (
ID_PELICULA ASC
);

/*==============================================================*/
/* Index: SE_CONFORMA_FK                                        */
/*==============================================================*/
create index SE_CONFORMA_FK on SE_CONFORMA (
ID_ELENCO ASC
);

/*==============================================================*/
/* Table: SE_PROYECTA                                           */
/*==============================================================*/
create table SE_PROYECTA 
(
   ID_CINE              integer                        not null,
   ID_PELICULA          integer                        not null,
   constraint PK_SE_PROYECTA primary key (ID_CINE, ID_PELICULA)
);

/*==============================================================*/
/* Index: SE_PROYECTA_PK                                        */
/*==============================================================*/
create unique index SE_PROYECTA_PK on SE_PROYECTA (
ID_CINE ASC,
ID_PELICULA ASC
);

/*==============================================================*/
/* Index: SE_PROYECTA2_FK                                       */
/*==============================================================*/
create index SE_PROYECTA2_FK on SE_PROYECTA (
ID_PELICULA ASC
);

/*==============================================================*/
/* Index: SE_PROYECTA_FK                                        */
/*==============================================================*/
create index SE_PROYECTA_FK on SE_PROYECTA (
ID_CINE ASC
);

/*==============================================================*/
/* Table: SE_VEN                                                */
/*==============================================================*/
create table SE_VEN 
(
   ID_FUNCION           integer                        not null,
   ID_SALA              integer                        not null,
   constraint PK_SE_VEN primary key (ID_FUNCION, ID_SALA)
);

/*==============================================================*/
/* Index: SE_VEN_PK                                             */
/*==============================================================*/
create unique index SE_VEN_PK on SE_VEN (
ID_FUNCION ASC,
ID_SALA ASC
);

/*==============================================================*/
/* Index: SE_VEN2_FK                                            */
/*==============================================================*/
create index SE_VEN2_FK on SE_VEN (
ID_SALA ASC
);

/*==============================================================*/
/* Index: SE_VEN_FK                                             */
/*==============================================================*/
create index SE_VEN_FK on SE_VEN (
ID_FUNCION ASC
);

/*==============================================================*/
/* Table: TRABAJA                                               */
/*==============================================================*/
create table TRABAJA 
(
   ID_DIRECTOR          integer                        not null,
   ID_ELENCO            integer                        not null,
   constraint PK_TRABAJA primary key (ID_DIRECTOR, ID_ELENCO)
);

/*==============================================================*/
/* Index: TRABAJA_PK                                            */
/*==============================================================*/
create unique index TRABAJA_PK on TRABAJA (
ID_DIRECTOR ASC,
ID_ELENCO ASC
);

/*==============================================================*/
/* Index: TRABAJA2_FK                                           */
/*==============================================================*/
create index TRABAJA2_FK on TRABAJA (
ID_ELENCO ASC
);

/*==============================================================*/
/* Index: TRABAJA_FK                                            */
/*==============================================================*/
create index TRABAJA_FK on TRABAJA (
ID_DIRECTOR ASC
);

alter table ESTABLECEN
   add constraint FK_ESTABLEC_ESTABLECE_PROMOCIO foreign key (ID_PROMOCION)
      references PROMOCIONES (ID_PROMOCION)
      on update restrict
      on delete restrict;

alter table ESTABLECEN
   add constraint FK_ESTABLEC_ESTABLECE_FUNCIONE foreign key (ID_FUNCION)
      references FUNCIONES (ID_FUNCION)
      on update restrict
      on delete restrict;

alter table GENERAN
   add constraint FK_GENERAN_GENERAN_COMENTAR foreign key (ID_OPINION)
      references COMENTARIOS (ID_OPINION)
      on update restrict
      on delete restrict;

alter table GENERAN
   add constraint FK_GENERAN_GENERAN2_FUNCIONE foreign key (ID_FUNCION)
      references FUNCIONES (ID_FUNCION)
      on update restrict
      on delete restrict;

alter table INTEGRADO
   add constraint FK_INTEGRAD_INTEGRADO_ACTORES foreign key (ID_ACTOR)
      references ACTORES (ID_ACTOR)
      on update restrict
      on delete restrict;

alter table INTEGRADO
   add constraint FK_INTEGRAD_INTEGRADO_ELENCO foreign key (ID_ELENCO)
      references ELENCO (ID_ELENCO)
      on update restrict
      on delete restrict;

alter table SALA
   add constraint FK_SALA_TIENE_CINE foreign key (ID_CINE)
      references CINE (ID_CINE)
      on update restrict
      on delete restrict;

alter table SE_CONFORMA
   add constraint FK_SE_CONFO_SE_CONFOR_ELENCO foreign key (ID_ELENCO)
      references ELENCO (ID_ELENCO)
      on update restrict
      on delete restrict;

alter table SE_CONFORMA
   add constraint FK_SE_CONFO_SE_CONFOR_PELICULA foreign key (ID_PELICULA)
      references PELICULA (ID_PELICULA)
      on update restrict
      on delete restrict;

alter table SE_PROYECTA
   add constraint FK_SE_PROYE_SE_PROYEC_CINE foreign key (ID_CINE)
      references CINE (ID_CINE)
      on update restrict
      on delete restrict;

alter table SE_PROYECTA
   add constraint FK_SE_PROYE_SE_PROYEC_PELICULA foreign key (ID_PELICULA)
      references PELICULA (ID_PELICULA)
      on update restrict
      on delete restrict;

alter table SE_VEN
   add constraint FK_SE_VEN_SE_VEN_FUNCIONE foreign key (ID_FUNCION)
      references FUNCIONES (ID_FUNCION)
      on update restrict
      on delete restrict;

alter table SE_VEN
   add constraint FK_SE_VEN_SE_VEN2_SALA foreign key (ID_SALA)
      references SALA (ID_SALA)
      on update restrict
      on delete restrict;

alter table TRABAJA
   add constraint FK_TRABAJA_TRABAJA_DIRECTOR foreign key (ID_DIRECTOR)
      references DIRECTOR (ID_DIRECTOR)
      on update restrict
      on delete restrict;

alter table TRABAJA
   add constraint FK_TRABAJA_TRABAJA2_ELENCO foreign key (ID_ELENCO)
      references ELENCO (ID_ELENCO)
      on update restrict
      on delete restrict;

