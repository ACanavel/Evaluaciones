package BIOTRENALE;
//Realizado por @MariaCanache
import java.io.ObjectInputStream.GetField;

import javax.swing.JOptionPane;

public class BIOTREN {
     
	public static void main(String[] args) {
		int op=0;
		
		
		do {
			
		USUARIO U1= new USUARIO();
		TARJETA T1= new TARJETA();
		
		JOptionPane.showMessageDialog(null,"Bienvenidos al Sistema BIOTREN" );
		
		op=op=Integer.parseInt(JOptionPane.showInputDialog("Seleccione: Estudiante ,Empleado o Adulto Mayor"
    			+ "\n 1 Estudiante  \n 2 Empleado  \n 3 Adulto Mayor \n 4 Salir "));
		
		if (op==1) {
	
		U1.setNombre(JOptionPane.showInputDialog(null, "Ingrese el nombre"));
		U1.setApellido(JOptionPane.showInputDialog(null, "Ingrese Primer Apellido"));
		U1.setRun(JOptionPane.showInputDialog(null, "Ingrese su Run"));
		U1.setEdad(Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese su Edad")));
		
		int opp=Integer.parseInt(JOptionPane.showInputDialog("Actualmente que nivel cursa?:"
    			+ "\n 1.Basica \n 2.Media 0 Universitaria "));
		
		     if(opp==1) {
	         T1.setTipo_tarjeta("Tarjeta TNE gratis");
	         T1.numero_tarjeta();	
	         JOptionPane.showMessageDialog(null," " +T1.getTipo_tarjeta()+ " \n su c�digo de Tarjeta es:" +T1.getNumero_tarjeta());
		     }
	         if(opp==2) {
	         T1.setSaldo(Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese el monto a recargar")));
	         T1.setTipo_tarjeta("Tarjeta TNE");
	         T1.numero_tarjeta();
	         JOptionPane.showMessageDialog(null," " +T1.getTipo_tarjeta()+ "\n su c�digo de tarjeta es:"  +T1.getNumero_tarjeta()+ "\n Su saldo es:" +T1.getSaldo());
		     }
		     }
		
	      if (op==2) {  
	    	U1.setNombre(JOptionPane.showInputDialog(null, "Ingrese el nombre"));
	  		U1.setApellido(JOptionPane.showInputDialog(null, "Ingrese Primer Apellido"));
	  		U1.setRun(JOptionPane.showInputDialog(null, "Ingrese su Run"));
	  		U1.setEdad(Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese su Edad")));
	  		T1.setSaldo(Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese el monto a recargar")));
	  		T1.setTipo_tarjeta("Tarjeta Com�n");
	  		T1.numero_tarjeta();
			JOptionPane.showMessageDialog(null," " +T1.getTipo_tarjeta()+ "\n su c�digo de tarjeta es:"  +T1.getNumero_tarjeta()+ "\nSu saldo es:" +T1.getSaldo());
	         
	      }
	      
	      if(op==3) {
	    	U1.setNombre(JOptionPane.showInputDialog(null, "Ingrese el nombre"));
	  		U1.setApellido(JOptionPane.showInputDialog(null, "Ingrese Primer Apellido"));
	  		U1.setRun(JOptionPane.showInputDialog(null, "Ingrese su Run"));
	  		U1.setEdad(Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese su Edad")));
	  		T1.setSaldo(Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese el monto a recargar")));
			T1.setTipo_tarjeta("Tarjeta Bip");
			T1.numero_tarjeta();
			JOptionPane.showMessageDialog(null," " +T1.getTipo_tarjeta()+ "\n su c�digo de tarjeta es:"  +T1.getNumero_tarjeta()+ "\n Su saldo es:" +T1.getSaldo());
		
		     
	      }
		     } while (op==4);
		}

	
	  
}       
		
     
	
       

      
	
