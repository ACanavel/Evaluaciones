package EMPLEADO;

public class Empleado {
      private String rut;
      private String nombre;
      private String apellidop;
      private String apellidom;
      private String cargo;
      private String direcci�n;
      private int tel�fono;
      private String Email;
	
      public Empleado(String rut, String nombre, String apellidop, String apellidom, String cargo) {
		super();
		this.rut = rut;
		this.nombre = nombre;
		this.apellidop = apellidop;
		this.apellidom = apellidom;
		this.cargo = cargo;
	}

	public Empleado(String rut, String nombre, String apellidop, String apellidom, String direcci�n, int tel�fono,
			String email) {
		super();
		this.rut = rut;
		this.nombre = nombre;
		this.apellidop = apellidop;
		this.apellidom = apellidom;
		this.direcci�n = direcci�n;
		this.tel�fono = tel�fono;
		Email = email;
	}

	public Empleado() {
		super();
	}

	public String getRut() {
		return rut;
	}

	public void setRut(String rut) {
		this.rut = rut;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidop() {
		return apellidop;
	}

	public void setApellidop(String apellidop) {
		this.apellidop = apellidop;
	}

	public String getApellidom() {
		return apellidom;
	}

	public void setApellidom(String apellidom) {
		this.apellidom = apellidom;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public String getDirecci�n() {
		return direcci�n;
	}

	public void setDirecci�n(String direcci�n) {
		this.direcci�n = direcci�n;
	}

	public int getTel�fono() {
		return tel�fono;
	}

	public void setTel�fono(int tel�fono) {
		this.tel�fono = tel�fono;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}
    
      
      
      
      
      
}
